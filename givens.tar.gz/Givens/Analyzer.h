#ifndef ANALYZER_H
#define ANALYZER_H

#include <stdio.h>
#include "Tokenizer.h"
#include "Parser.h"

#endif